<?php include 'header.php' ;?>
<!-- End Header -->

<!-- Start Dashboard -->
<section class="AboutUS">
	<div class="container">
		<div class="Heading">
			<h4>About Us</h4>
		</div>
		<div class="AboutUSP">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
				<br><br>
			Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.
				<br><br>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.
				<br><br>
			 In voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</p>
		<p>Our Value System:</p>
		<p>Iulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		<p>1. WILL TO WIN:</p>
		<p>Ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidata.</p>
		<p>2. COMMITMENT TO CUSTOMERS:</p>
		<p>Tnon	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		<p>3. INTEGRITY:</p>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
		<p>4. PERSONAL ACCOUNTABILITY:</p>
		<p> Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. efforts and make them better.</p>
		<p>5. RESPECT FOR PEOPLE:</p>
		<p>Respect for customers, company staff and fellow affiliates is what we follow from heart.</p>
		<p>6. CONTINUOUS LEARNING:</p>
		<p>A winner is always a lifelong learner. At  keep learning from our experiences and other sources to grow &amp; upgrade ourselves to serve you better.</p>
		<p>7. QUALITY:</p>
		<p>As an organisation, Quality is at our utmost priority in terms of product, services, system and experience for our customers.</p>
		<p>Tour and Travel MANAGEMENT:</p>
		<p>Prakash Dubey
			<br>(Co-founder, Business Head)</p>
			<p>Pankaj Joshi<br>(Co-founder, Marketing Head)</p>
		</div>
	</div>
</section>
<!-- End Dashboard -->



<!-- Start Footer -->
<?php include 'footer.php';?>


